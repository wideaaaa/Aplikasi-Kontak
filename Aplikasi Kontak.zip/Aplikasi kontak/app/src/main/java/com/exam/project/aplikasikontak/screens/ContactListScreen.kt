package com.exam.project.aplikasikontak.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.exam.project.aplikasikontak.components.CategoryChip
import com.exam.project.aplikasikontak.components.ContactCard
import com.exam.project.aplikasikontak.components.ContactDetail
import com.exam.project.aplikasikontak.components.SectionHeader
import com.exam.project.aplikasikontak.data.Contact
import com.exam.project.aplikasikontak.data.ContactCategory
import com.exam.project.aplikasikontak.data.dummyContacts

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ContactListScreen(
    isDarkMode: Boolean,
    onThemeToggle: (Boolean) -> Unit
) {
    var selectedCategory by rememberSaveable { mutableStateOf(ContactCategory.ALL) }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var selectedContact by remember { mutableStateOf<Contact?>(null) }

    val filteredContacts = remember(searchQuery, selectedCategory) {
        dummyContacts.filter { contact ->
            val matchesCategory = when (selectedCategory) {
                ContactCategory.ALL -> true
                ContactCategory.FAVORITE -> contact.isFavorite
                else -> contact.category == selectedCategory
            }
            val matchesSearch = contact.name.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesSearch
        }
    }

    val groupedContacts = remember(filteredContacts) {
        filteredContacts.groupBy { it.name.first().uppercaseChar() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = "Aplikasi Kontak",
                        style = MaterialTheme.typography.titleLarge
                    ) 
                },
                actions = {
                    Text(text = if (isDarkMode) "🌙" else "☀️", modifier = Modifier.padding(end = 8.dp))
                    Switch(
                        checked = isDarkMode,
                        onCheckedChange = onThemeToggle,
                        modifier = Modifier.padding(end = 16.dp)
                    )
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Feature 1: Search TextField
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text("Cari kontak...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = MaterialTheme.shapes.medium
            )

            // LazyRow for Categories
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
            ) {
                items(ContactCategory.entries.toTypedArray()) { category ->
                    CategoryChip(
                        category = category,
                        isSelected = selectedCategory == category,
                        onClick = { selectedCategory = category }
                    )
                }
            }

            // LazyColumn with Sticky Headers and Animations
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
            ) {
                groupedContacts.forEach { (initial, contacts) ->
                    stickyHeader {
                        SectionHeader(title = initial.toString())
                    }

                    items(contacts, key = { it.id }) { contact ->
                        ContactCard(
                            contact = contact,
                            onClick = { selectedContact = contact },
                            // Feature 3: Animation
                            modifier = Modifier.animateItem()
                        )
                    }
                }
                
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }

    // Feature 2: Contact Detail Dialog
    selectedContact?.let { contact ->
        ContactDetail(
            contact = contact,
            onDismiss = { selectedContact = null }
        )
    }
}
