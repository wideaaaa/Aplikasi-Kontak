package com.exam.project.aplikasikontak.data

enum class ContactCategory(val label: String, val icon: String) {
    ALL("Semua", "📱"),
    FAVORITE("Favorit", "⭐"),
    FAMILY("Keluarga", "👨‍👩‍👧‍👦"),
    FRIEND("Teman", "🤝"),
    WORK("Kerja", "💼")
}

data class Contact(
    val id: Int,
    val name: String,
    val phoneNumber: String,
    val email: String,
    val category: ContactCategory,
    val isFavorite: Boolean = false,
    val imageRes: Int? = null
)

val dummyContacts = listOf(
    Contact(1, "Ahmad Fauzi", "08123456789", "ahmad@mail.com", ContactCategory.FAMILY),
    Contact(2, "Adik Rini", "08123456790", "rini@mail.com", ContactCategory.FAMILY),
    Contact(3, "Apotek Sehat", "08123456791", "apotek@mail.com", ContactCategory.WORK),
    Contact(4, "Bapak Kukuh", "08123456792", "kukuh@mail.com", ContactCategory.FAMILY, true, com.exam.project.aplikasikontak.R.drawable.bapak_kukuh),
    Contact(5, "Bengkel Motor", "08123456793", "bengkel@mail.com", ContactCategory.WORK),
    Contact(6, "Citra Lestari", "08123456794", "citra@mail.com", ContactCategory.FRIEND, true, com.exam.project.aplikasikontak.R.drawable.citra_lestari),
    Contact(7, "Dedi Irawan", "08123456795", "dedi@mail.com", ContactCategory.FRIEND),
    Contact(8, "Eko Prasetyo", "08123456796", "eko@mail.com", ContactCategory.WORK),
    Contact(9, "Fani Amalia", "08123456797", "fani@mail.com", ContactCategory.FAMILY),
    Contact(10, "Gani Wijaya", "08123456798", "gani@mail.com", ContactCategory.FRIEND),
    Contact(11, "Hani Handayani", "08123456799", "hani@mail.com", ContactCategory.FAMILY),
    Contact(12, "Irfan Hakim", "08123456800", "irfan@mail.com", ContactCategory.WORK),
    Contact(13, "Joko Susilo", "08123456801", "joko@mail.com", ContactCategory.FRIEND),
    Contact(14, "Kurnia Sari", "08123456802", "kurnia@mail.com", ContactCategory.FAMILY),
    Contact(15, "Gilbeth", "08123456803", "gilbeth@mail.com", ContactCategory.FAMILY, true, com.exam.project.aplikasikontak.R.drawable.gilbeth)
).sortedBy { it.name }
